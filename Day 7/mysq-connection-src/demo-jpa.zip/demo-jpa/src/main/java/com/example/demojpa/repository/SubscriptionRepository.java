package com.example.demojpa.repository;

import com.example.demojpa.domain.Subscription;
import org.springframework.data.repository.CrudRepository;

public interface SubscriptionRepository extends CrudRepository<Subscription, Long>{

}
