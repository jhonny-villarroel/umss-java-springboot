package com.example.demojpa.repository;

import com.example.demojpa.domain.Teacher;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by jhonny on 5/26/17.
 */
public interface TeacherRepository extends CrudRepository<Teacher, Long> {
    //@Query("select u from Teacher u where u.name like %?1")
    //List<Person> findByName(String name);
    Teacher getTeacherById(Long id);

}
