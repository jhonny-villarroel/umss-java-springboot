package com.example.demojpa.service;

import com.example.demojpa.domain.Teacher;
import com.example.demojpa.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeacherService {
    @Autowired
    private TeacherRepository teacherRepository;

    public Iterable<Teacher> getAllTeachers(){
        return teacherRepository.findAll();
    }

    public void addTeacher(Teacher newTeacher){
        teacherRepository.save(newTeacher);
    }

    public void deleteTeacher(Teacher teacher){
        teacherRepository.delete(teacher);
    }

    public void updateTeacher(Teacher teacher){
        teacherRepository.save(teacher);
    }

}
