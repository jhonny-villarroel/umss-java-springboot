package com.example.demojpa.service;

import com.example.demojpa.domain.Student;
import com.example.demojpa.domain.Subscription;
import com.example.demojpa.domain.Teacher;
import com.example.demojpa.repository.StudentRepository;
import com.example.demojpa.repository.SubscriptionRepository;
import com.example.demojpa.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class SubcribtionService {
    // como servicio yo deberia utilizar Repositories
    @Autowired
    private SubscriptionRepository subscriptionRepository;
    @Autowired
    private TeacherRepository teacherRepository;
    @Autowired
    private StudentRepository studentRepository;

    /// Services Los controladores
    @Autowired
    private TeacherService teacherService;
    @Autowired
    private StudentService studentService;

    // list all
    public Iterable<Subscription> getAllSubscritions(){
        return subscriptionRepository.findAll();
    }
    // Add a new Subscription
    public void addSubscription(Long idTeacher, Long idStudent){
        Subscription newSubcriptio = new Subscription();
        // get a student from Id
        Student student =  studentRepository.getStudentById(idStudent);
        newSubcriptio.setStudent(student);
        // teachers
        Teacher teacher =  teacherRepository.getTeacherById(idTeacher);
        newSubcriptio.setStudent(student);
        newSubcriptio.setTeacher(teacher);

    }


}
