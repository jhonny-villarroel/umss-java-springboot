package com.dharbor.set.persistence.chat.services;


import org.springframework.stereotype.Service;

/**
 * @author ivan.alban
 */
@Service
public class ConversationService {



    public void create(String resourceId) {

    }


}
