package com.dharbor.set.persistence.chat.data.domain;

import java.util.List;

/**
 * @author ivan.alban
 */
public class ConversationEntity {

    private String id;


}
