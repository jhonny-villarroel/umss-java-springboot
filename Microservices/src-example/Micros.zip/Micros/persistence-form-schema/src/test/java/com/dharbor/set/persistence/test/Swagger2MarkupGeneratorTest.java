package com.dharbor.set.persistence.test;

/**
 * @author ivan.alban
 */
public class Swagger2MarkupGeneratorTest {
}
