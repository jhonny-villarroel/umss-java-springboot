package com.dharbor.set.persistence.chat.rest;


import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;
import io.swagger.annotations.Api;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


/**
 * @author ivan.alban
 */
@Api
@RestController
@RequestMapping("/forms")
public class FormPersistenceController {


    @Autowired
    private MongoTemplate mongoTemplate;
    private static String COLLECTION_NAME="form-schema";
    @RequestMapping(method = RequestMethod.POST)
    public  ResponseEntity<String>  saveForm(@RequestBody String  jsonString) {
        DBObject dbObject = (DBObject) com.mongodb.util.JSON.parse(jsonString);
        mongoTemplate.insert(dbObject, COLLECTION_NAME);

        return ResponseEntity.ok(dbObject.get("_id").toString());
    }

    @RequestMapping(
            value = "/{formId}",
            method = RequestMethod.GET
    )
    public ResponseEntity<Object> findForm(@PathVariable("formId") String formId) {

        DB db = mongoTemplate.getDb();
        DBCollection collection =  db.getCollection(COLLECTION_NAME);
        DBObject dbres = collection.findOne(new ObjectId(formId));
        String res = JSON.serialize(dbres);
       return ResponseEntity.ok(JSON.parse(res));
    }


    @RequestMapping(

            method = RequestMethod.GET
    )
    public ResponseEntity<Object> findAllForm() {

        DB db = mongoTemplate.getDb();
        DBCollection collection =  db.getCollection(COLLECTION_NAME);
        DBCursor dbres = collection.find();
        List<DBObject> listObject = new ArrayList<>();
        for(DBObject dbobject : dbres){
            listObject.add(dbobject);

        }
        String res = JSON.serialize(dbres);
        return ResponseEntity.ok(listObject);
    }
}
