package com.dharbor.set.persistence.chat.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author jhonny.villarroel
 */

@Component
@ConfigurationProperties(prefix = "cors")
public class CorsConfig {

    private String allowOrigin;

    public String getAllowOrigin() {
        return allowOrigin;
    }

    public void setAllowOrigin(String allowOrigin) {
        this.allowOrigin = allowOrigin;
    }
}