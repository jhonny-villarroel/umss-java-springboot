package com.dharbor.set.persistence.test;

/**
 * @author jhonny.villarroel
 */
public class Swagger2MarkupGeneratorTest {
}
