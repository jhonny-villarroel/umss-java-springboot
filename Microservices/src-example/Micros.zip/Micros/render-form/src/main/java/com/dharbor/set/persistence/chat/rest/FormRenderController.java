package com.dharbor.set.persistence.chat.rest;


import com.dharbor.set.persistence.chat.services.FormRenderService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;

/**
 * @author jhonny.villarroel
 */
@Api
@RestController
@RequestMapping("/form-render")
public class FormRenderController {

    @Autowired
    private FormRenderService formRenderService;


    @RequestMapping(
            value = "/{formId}",
            method = RequestMethod.GET
    )

    public String renderFormById(@PathVariable("formId") String formId) {
        String json = formRenderService.getFormAsJson(formId);
        return renderJSONToHTML(json);
    }

    private String renderJSONToHTML(String json)     {
        //ObjectMapper mapper = new ObjectMapper();
       // JsonNode actualObj = mapper.readTree(json);
        //actualObj.get();
        return "<form id=\"rendered-form\">" +
                "<div class=\"rendered-form\">" +
                "<div class=\"fb-text form-group field-text-1508241338405\">" +
                "<label for=\"text-1508241338405\" class=\"fb-text-label\">UserName</label>" +
                "<input type=\"text\" class=\"form-control\" name=\"text-1508241338405\" id=\"text-1508241338405\">" +
                "</div><div class=\"fb-text form-group field-text-1508241340462\">" +
                "<label for=\"text-1508241340462\" class=\"fb-text-label\">Password</label>" +
                "<input type=\"text\" class=\"form-control\" name=\"text-1508241340462\" id=\"text-1508241340462\">" +
                "</div><div class=\"fb-button form-group field-button-1508241587749\">" +
                "<button type=\"button\" class=\"btn btn-success\" name=\"button-1508241587749\" style=\"success\" id=\"button-1508241587749\">Submit</button>" +
                "</div></div></form>";
    }
}
