package com.dharbor.set.persistence.chat.services;


import com.dharbor.set.persistence.chat.data.api.FormPersistenceClient;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author jhonny.villarroel
 */
@Service
public class FormRenderService {

    @Autowired
    private FormPersistenceClient conversationClient;
    @HystrixCommand
    public String getFormAsJson(String resourceId) {
        Object obj = conversationClient.findFormById(resourceId);
        System.out.println(obj.toString());
        return obj.toString();
    }


}
