package com.dharbor.set.persistence.chat.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * @author jhonny.villarroel
 */
@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = FormNotFoundException.CODE)
public class FormNotFoundException extends RuntimeException {
    public static final String CODE = "CONTENT_NOT_FOUND";
}
