package com.dharbor.set.persistence.chat.data.api;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.*;

/**
 * @author jhonny.villarroel
 */
@FeignClient(name = "persistence-form-schema")
public interface FormPersistenceClient {


    @RequestMapping(
            method = RequestMethod.GET,
            value = "/forms/{formId}"
    )
    Object findFormById(@RequestParam("formId") String formId);

}
