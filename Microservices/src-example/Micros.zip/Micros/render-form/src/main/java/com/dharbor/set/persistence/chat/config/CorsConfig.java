package com.dharbor.set.persistence.chat.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import javax.servlet.FilterConfig;

/**
 * @author jhonny.villarroel
 */

@Component
@ConfigurationProperties(prefix = "cors")
public class CorsConfig {

    private String allowOrigin;

    public String getAllowOrigin() {
        return allowOrigin;
    }

    public void setAllowOrigin(String allowOrigin) {
        this.allowOrigin = allowOrigin;
    }
}