package com.dh.demo.dataFetchers;

import com.dh.demo.domain.Teacher;
import com.dh.demo.service.TeacherService;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class AllTeachersDataFetcher implements DataFetcher<List<Teacher>> {
    @Autowired
    private TeacherService teacherService;

   // @Autowired
    //AllUsersDataFetcher(UserService userService){
        //this.userService = userService;
    //}

    @Override
    public List<Teacher> get(DataFetchingEnvironment env) {
        //Teacher teacher =  env.getSource();
        //List<Teacher> teachers = new ArrayList<>();
        /*
        if(teacher !=null){
            teachers = teacherService.getAllTeachers();
        }else {
            teachers = teacherService.findById();
        }*/
        //teachers = teacherService.getAllTeachers();
        return teacherService.getAllTeachers();
    }
}
