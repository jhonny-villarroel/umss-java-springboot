package com.dh.demo.dataFetchers;


import com.dh.demo.domain.Teacher;
import com.dh.demo.service.TeacherService;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
@Component
public class TeacherDataFetcher implements DataFetcher<Teacher> {
    @Autowired
    private TeacherService teacherService;


    @Override
    public Teacher get(DataFetchingEnvironment env) {
        Map args = env.getArguments();
        Teacher teacher = teacherService.findById(String.valueOf(args.get("Id")));
        return teacher;
    }
}
