package com.dh.demo.graphql_utilities;

import com.dh.demo.dataFetchers.AllTeachersDataFetcher;
import com.dh.demo.dataFetchers.TeacherDataFetcher;
import graphql.GraphQL;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;


import javax.annotation.PostConstruct;
import java.io.File;
import java.io.IOException;

import static graphql.GraphQL.newGraphQL;
import static graphql.schema.idl.RuntimeWiring.newRuntimeWiring;

@Component
public class GraphQlUtility {

    @Value("classpath:schemas.graphqls")
    private Resource schemaResource;
    private GraphQL graphQL;
    @Autowired
   private AllTeachersDataFetcher allTeachersDataFetcher;
    @Autowired
    private TeacherDataFetcher teacherDataFetcher;
    //private ArticlesDataFetcher articlesDataFetcher;

//    @Autowired
  //  GraphQlUtility(TeacherDataFetcher teacherDataFetcher, AllTeachersDataFetcher allTeachersDataFetcher
      //             ) throws IOException {
        //this.allUsersDataFetcher = allUsersDataFetcher;
    //    this.teacherDataFetcher = teacherDataFetcher;
        //this.allTeachersDataFetcher = allTeachersDataFetcher;
        //this.articlesDataFetcher = articlesDataFetcher;
    //}

    @PostConstruct
    public GraphQL createGraphQlObject() throws IOException {
        File schemas = schemaResource.getFile();
        TypeDefinitionRegistry typeRegistry = new SchemaParser().parse(schemas);
        RuntimeWiring wiring = buildRuntimeWiring();
        GraphQLSchema schema = new SchemaGenerator().makeExecutableSchema(typeRegistry, wiring);
        return  newGraphQL(schema).build();
    }

    public RuntimeWiring buildRuntimeWiring(){
        return newRuntimeWiring()
                .type("Query", typeWiring -> typeWiring
                    .dataFetcher("teachers", allTeachersDataFetcher)
                    .dataFetcher("user", teacherDataFetcher))
               // .type("User", typeWiring -> typeWiring
                 //   .dataFetcher("articles", articlesDataFetcher)
                  //  .dataFetcher("friends", allUsersDataFetcher))
                .build();
    }
}

