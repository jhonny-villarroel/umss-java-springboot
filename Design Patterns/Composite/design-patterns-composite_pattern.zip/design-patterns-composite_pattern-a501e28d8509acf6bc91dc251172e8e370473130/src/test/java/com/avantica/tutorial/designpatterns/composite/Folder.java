package com.avantica.tutorial.designpatterns.composite;;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jhonny on 8/5/2017.
 */
public class Folder extends Data {
    private final static String TYPE="Folder";
    private List<Data> listFile;
    private String folderName;
    public Folder(String folderName){
        listFile = new ArrayList<Data>();
        this.folderName = folderName;
    }

    @Override
    public Data getChild(int i) {
        return listFile.get(i);
    }

    @Override
    public String getType() {
        return TYPE;
    }

    @Override
    public void addData(Data newData) {
        listFile.add(newData);
    }

    @Override
    public String getDataName() {
        return folderName;
    }
}
