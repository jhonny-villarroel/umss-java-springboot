package com.avantica.tutorial.designpatterns.composite;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * Created by jhonny on 8/5/2017.
 */
public abstract class Data {

    public void addData(Data newData) {
        throw new NotImplementedException();
    }

    public void remove(Data removeData) {
        throw new NotImplementedException();
    }

    public Data getChild(int i) {
        throw new NotImplementedException();
    }

    public String getDataName() {
        throw new NotImplementedException();
    }

    public String getType() {
        throw new NotImplementedException();
    }

}
