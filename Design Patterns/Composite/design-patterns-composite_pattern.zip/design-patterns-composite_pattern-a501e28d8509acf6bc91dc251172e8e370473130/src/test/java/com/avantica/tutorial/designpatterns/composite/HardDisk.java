package com.avantica.tutorial.designpatterns.composite;;

/**
 * Created by jhonny on 8/5/2017.
 */
public class HardDisk {
}
