package com.avantica.tutorial.designpatterns.composite;;

/**
 * Created by jhonny on 8/5/2017.
 */
public class File extends Data{
    private final static String TYPE="File";
    private String fileName;
    public File(String fileName){
        this.fileName = fileName;
    }
    @Override
    public String getType() {
        return TYPE;
    }

    @Override
    public String getDataName() {
        return fileName;
    }
}
