package com.avantica.tutorial.designpatterns;

import com.avantica.tutorial.designpatterns.composite.File;
import com.avantica.tutorial.designpatterns.composite.Folder;
import org.junit.Assert;
import org.junit.Test;

import com.avantica.tutorial.designpatterns.singleton.SingletonService;

public class DesignPatternsShowCase {

    @Test
    public void singleton() {
        SingletonService instance = SingletonService.getInstance();
        SingletonService sameInstance = SingletonService.getInstance();

        Assert.assertTrue(instance == sameInstance);
    }
    @Test
    public void composite(){
        Folder mainFolder = new Folder("Main Folder");
        Folder folder1 = new Folder("folder 1");
        Folder folder2 = new Folder("folder 2");
        Folder folder3 = new Folder("folder 2");

        // add to main folder
        mainFolder.addData(new File("file1"));
        mainFolder.addData(folder1);
        mainFolder.addData(folder2);
        mainFolder.addData(folder3);
        // add to folder 1
        folder1.addData(new File("file 2"));
        folder1.addData(new File("file 3"));
        // add to folder 2
        Folder folder4 = new Folder("folder 4");
        Folder folder5 = new Folder("folder 5");

        folder2.addData(folder4);
        folder2.addData(folder5);

        // add to folder 4
        folder4.addData(new File("file 4"));
        folder4.addData(new File("file 5"));

        Assert.assertEquals(mainFolder.getChild(0).getType(), "File");
        Assert.assertEquals(mainFolder.getChild(1).getType(), "Folder");
        Assert.assertEquals(mainFolder.getChild(2).getType(), "Folder");
        Assert.assertEquals(mainFolder.getChild(1).getChild(0).getDataName(), "file 2");
        Assert.assertEquals(mainFolder.getChild(1).getChild(1).getDataName(), "file 3");
    }

}
