package com.avantica.tutorial.designpatterns.nullobject;


import java.util.ArrayList;
import java.util.List;

/**
 * Created by jhonny on 8/7/2017.
 */
public class ComputerBios {

    private List<HardDisk> listDisk;
    public ComputerBios(){
        listDisk = new ArrayList<HardDisk>();
    }

    public String connectDisk(HardDisk hardDisk){
        String diskInfo = "";
        listDisk.add(hardDisk);
        if(hardDisk.checksum()){
            return hardDisk.getDiskInfo();
        } else {
            // damage disk
            return ((DamageDisk)hardDisk).getDamageDiskInfo();
        }
    }
}
