package com.avantica.tutorial.designpatterns.nullobject;

/**
 * Created by jhonny on 8/7/2017.
 */
public class NewDisk extends HardDisk {

    public NewDisk( String brand){
        super(0, brand);
    }

    @Override
    public String getDiskInfo() {
        return "Disk:"+ this.brand + "(Not Formated Disk)";
    }
}
