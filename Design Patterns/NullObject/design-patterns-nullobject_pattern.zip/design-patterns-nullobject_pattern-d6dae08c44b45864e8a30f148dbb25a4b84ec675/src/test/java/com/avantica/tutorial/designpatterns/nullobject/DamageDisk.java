package com.avantica.tutorial.designpatterns.nullobject;

/**
 * Created by jhonny on 8/7/2017.
 */
public class DamageDisk extends HardDisk {

    public DamageDisk() {
        super(0, "");
    }

    @Override
    public String getDiskInfo() {
        return "Not Detected";
    }

    public String getDamageDiskInfo(){return getDiskInfo();}
    @Override
    public boolean checksum() {
        return false;
    }
}
