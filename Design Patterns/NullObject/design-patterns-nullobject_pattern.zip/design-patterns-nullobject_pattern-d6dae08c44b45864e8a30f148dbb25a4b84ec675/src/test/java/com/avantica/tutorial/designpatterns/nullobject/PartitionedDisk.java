package com.avantica.tutorial.designpatterns.nullobject;

/**
 * Created by jhonny on 8/7/2017.
 */
public class PartitionedDisk extends HardDisk {
    private int diskPartition;

    public PartitionedDisk(int numPartitions, String brand){
        super(numPartitions, brand);
    }

    @Override
    public String getDiskInfo() {
        return "Disk: "+ this.brand + "Number of Partitions: "+ numPartitions;
    }
}
