package com.avantica.tutorial.designpatterns.nullobject;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * Created by jhonny on 8/7/2017.
 */
public abstract class HardDisk {

    protected int numPartitions;
    protected String brand;


    public HardDisk(int numPartitions, String brand){
        this.brand = brand;
        this.numPartitions = numPartitions;
    }

    public String getBrand() {
        return brand;
    }

    public int getNumPartitions() {
        return numPartitions;
    }

    public String getDiskInfo() {
        return "";
    }

    public void setNumPartitions(int numPartitions) {
        this.numPartitions = numPartitions;
    }


    public void setBrand(String brand) {
        this.brand = brand;
    }

    public boolean checksum(){
       return  true;
    }
}
