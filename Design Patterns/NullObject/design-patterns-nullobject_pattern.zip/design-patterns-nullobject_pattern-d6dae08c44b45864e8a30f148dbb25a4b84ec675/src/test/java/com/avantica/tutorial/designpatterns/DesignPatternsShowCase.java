package com.avantica.tutorial.designpatterns;

import com.avantica.tutorial.designpatterns.nullobject.ComputerBios;
import com.avantica.tutorial.designpatterns.nullobject.DamageDisk;
import com.avantica.tutorial.designpatterns.nullobject.NewDisk;
import com.avantica.tutorial.designpatterns.nullobject.PartitionedDisk;
import org.junit.Assert;
import org.junit.Test;

import com.avantica.tutorial.designpatterns.singleton.SingletonService;

public class DesignPatternsShowCase {

    @Test
    public void singleton() {
        SingletonService instance = SingletonService.getInstance();
        SingletonService sameInstance = SingletonService.getInstance();

        Assert.assertTrue(instance == sameInstance);
    }
    @Test
    public void nullObject(){
        ComputerBios bios = new ComputerBios();

        // create hard disks
        NewDisk newDisk = new NewDisk("HITACHI");
        PartitionedDisk partitionedDisk =  new PartitionedDisk(3, "SAMSUNG");
        DamageDisk damageDisk = new DamageDisk();

        Assert.assertNotSame(bios.connectDisk(newDisk), "Not Detected");
        Assert.assertNotSame(bios.connectDisk(partitionedDisk), "Not Detected");
        Assert.assertEquals(bios.connectDisk(damageDisk), "Not Detected");
    }

}
