package com.avantica.tutorial.designpatterns.prototype;

/**
 * Created by Avantica20 on 8/8/2017.
 */
public class SSDDisk extends DiskPrototype {

    public SSDDisk(String brand, int size, DiskType diskType) {
        super(brand, size, diskType);
    }

    @Override
    public void saveData(Object data) {
        System.out.println("Save Data:"+ data.toString() +" in CI-Flash Memory");
    }
}
