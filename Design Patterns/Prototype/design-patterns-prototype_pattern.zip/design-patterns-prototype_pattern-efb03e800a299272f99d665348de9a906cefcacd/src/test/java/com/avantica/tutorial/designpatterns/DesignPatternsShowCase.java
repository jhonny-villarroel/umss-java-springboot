package com.avantica.tutorial.designpatterns;


import com.avantica.tutorial.designpatterns.prototype.DiskPrototype;
import com.avantica.tutorial.designpatterns.prototype.HDDisk;
import com.avantica.tutorial.designpatterns.prototype.SSDDisk;
import org.junit.Assert;
import org.junit.Test;

import com.avantica.tutorial.designpatterns.singleton.SingletonService;

public class DesignPatternsShowCase {

    @Test
    public void singleton() {
        SingletonService instance = SingletonService.getInstance();
        SingletonService sameInstance = SingletonService.getInstance();

        Assert.assertTrue(instance == sameInstance);
    }

    @Test
    public void prototype(){

        HDDisk hhdisk_base = new HDDisk("HITACHI", 1024, DiskPrototype.DiskType.HD);
        HDDisk hhdisk_clone = (HDDisk) hhdisk_base.clone();
        hhdisk_base.saveData("data string");
        hhdisk_clone.saveData("data string");

        Assert.assertEquals(hhdisk_base.getBrand(), hhdisk_clone.getBrand());
        Assert.assertEquals(hhdisk_clone.getDiskType(), DiskPrototype.DiskType.HD);
        Assert.assertEquals(hhdisk_base.getHardwarID(), hhdisk_clone.getHardwarID());

        SSDDisk ssdisk_base = new SSDDisk("SUNDISK", 1024, DiskPrototype.DiskType.SSD);
        SSDDisk ssddisk_clone = (SSDDisk) ssdisk_base.clone();
        ssdisk_base.saveData("data string");
        ssddisk_clone.saveData("data string");

        Assert.assertEquals(ssdisk_base.getBrand(), ssddisk_clone.getBrand());
        Assert.assertEquals(ssddisk_clone.getDiskType(), DiskPrototype.DiskType.SSD);
        Assert.assertEquals(ssdisk_base.getHardwarID(), ssddisk_clone.getHardwarID());






    }

}
