package com.avantica.tutorial.designpatterns.prototype;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.rmi.server.UID;
import java.util.UUID;

/**
 * Created by Avantica20 on 8/8/2017.
 */
public abstract class DiskPrototype  implements Cloneable  {
    protected String brand;
    protected int size;
    protected DiskType diskType;
    private String ID;

    public DiskPrototype(String brand, int size, DiskType diskType){
        this.brand = brand;
        this.size = size;
        this.diskType =  diskType;
        ID = UUID.randomUUID().toString();
    }

    public void saveData(Object data){
        throw new NotImplementedException();
    }

    public String getHardwarID(){
        return ID;
    }

    public Object clone() {
        Object clone = null;

        try {
            clone = super.clone();

        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        return clone;
    }


    public String getBrand() {
        return brand;
    }

    public int getSize() {
        return size;
    }

    public DiskType getDiskType() {
        return diskType;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public void setDiskType(DiskType diskType) {
        this.diskType = diskType;
    }
    public enum DiskType{
        SSD,
        HD;
    }
}
