package com.avantica.tutorial.designpatterns.prototype;

/**
 * Created by Avantica20 on 8/8/2017.
 */
public class HDDisk extends DiskPrototype {

    public HDDisk(String brand, int size, DiskType diskType){
        super(brand,size, diskType);
    }

    @Override
    public void saveData(Object data) {
        System.out.println("Save data : "+ data.toString() +"in Magnetic Disk");
    }
}
