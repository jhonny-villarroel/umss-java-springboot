package com.avantica.tutorial.designpatterns.templatemethod;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * Created by jhonny on 8/7/2017.
 */
public abstract class ComputerMonitor {


    public void showImage(){
        throw new NotImplementedException();
    }

    public String connectVGA(){
       return null;
    }

    public String connectHDMI(){
        return null;
    }

    public String connectDVI(){
        return null;
    }
}
