package com.avantica.tutorial.designpatterns.templatemethod;

/**
 * Created by jhonny on 8/7/2017.
 */
public class LCDMonitor extends ComputerMonitor {

    @Override
    public void showImage() {
        System.out.println("Show image in LCD computer");
    }

    @Override
    public String connectHDMI() {
        return "HDMI-transmit";
    }

    @Override
    public String connectVGA() {
        return "VGA-transmit";
    }

}
