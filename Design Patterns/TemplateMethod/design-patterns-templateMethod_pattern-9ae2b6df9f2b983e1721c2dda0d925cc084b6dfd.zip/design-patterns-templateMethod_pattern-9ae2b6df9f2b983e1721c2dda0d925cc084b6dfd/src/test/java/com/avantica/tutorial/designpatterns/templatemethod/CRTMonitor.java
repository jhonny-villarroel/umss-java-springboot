package com.avantica.tutorial.designpatterns.templatemethod;

/**
 * Created by jhonny on 8/7/2017.
 */
public class CRTMonitor extends ComputerMonitor {


    @Override
    public void showImage() {
        System.out.println("Show image in CRT Monitor");
    }

    @Override
    public String connectVGA() {
        return "VGA-transmit";
    }
}
