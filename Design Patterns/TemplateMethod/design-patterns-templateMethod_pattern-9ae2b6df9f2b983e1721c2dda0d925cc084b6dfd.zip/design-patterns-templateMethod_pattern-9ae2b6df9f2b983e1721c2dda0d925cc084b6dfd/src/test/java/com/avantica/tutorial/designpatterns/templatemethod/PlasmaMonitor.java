package com.avantica.tutorial.designpatterns.templatemethod;

/**
 * Created by jhonny on 8/7/2017.
 */
public class PlasmaMonitor extends ComputerMonitor {



    @Override
    public String connectHDMI() {
        return "HDMI-transmit";
    }

    @Override
    public void showImage() {
        System.out.println("Show image in Plasma Monitor");
    }
}
