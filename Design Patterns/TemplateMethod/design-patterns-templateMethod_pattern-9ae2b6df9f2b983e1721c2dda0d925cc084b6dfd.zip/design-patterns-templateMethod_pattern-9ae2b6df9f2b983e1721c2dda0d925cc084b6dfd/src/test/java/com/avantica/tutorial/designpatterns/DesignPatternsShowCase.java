package com.avantica.tutorial.designpatterns;

import com.avantica.tutorial.designpatterns.templatemethod.CRTMonitor;
import com.avantica.tutorial.designpatterns.templatemethod.LCDMonitor;
import com.avantica.tutorial.designpatterns.templatemethod.PlasmaMonitor;
import org.junit.Assert;
import org.junit.Test;

import com.avantica.tutorial.designpatterns.singleton.SingletonService;

public class DesignPatternsShowCase {

    @Test
    public void singleton() {
        SingletonService instance = SingletonService.getInstance();
        SingletonService sameInstance = SingletonService.getInstance();

        Assert.assertTrue(instance == sameInstance);
    }

    @Test
    public void templateMethod(){
        CRTMonitor crtMonitor =  new CRTMonitor();
        Assert.assertEquals(crtMonitor.connectVGA(), "VGA-transmit");
        Assert.assertEquals(crtMonitor.connectHDMI(), null);
        Assert.assertEquals(crtMonitor.connectDVI(), null);

        LCDMonitor lcdMonitor =  new LCDMonitor();
        Assert.assertEquals(lcdMonitor.connectHDMI(), "HDMI-transmit");
        Assert.assertEquals(lcdMonitor.connectVGA(), "VGA-transmit");
        Assert.assertEquals(lcdMonitor.connectDVI(), null);

        PlasmaMonitor plasmaMonitor =  new PlasmaMonitor();
        Assert.assertEquals(plasmaMonitor.connectHDMI(), "HDMI-transmit");
        Assert.assertEquals(plasmaMonitor.connectVGA(), null);
        Assert.assertEquals(plasmaMonitor.connectDVI(), null);
    }

}
