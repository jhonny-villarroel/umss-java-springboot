package com.avantica.tutorial.designpatterns.facade;

/**
 * Created by jhonny on 8/6/2017.
 */
public class MicrocontrollerLCD {

    private LCDDisplay lcdDisplay;
    private LCDDisplayDriver lcdDisplayDriver;
    public MicrocontrollerLCD(){
        lcdDisplay = new LCDDisplay();
        lcdDisplayDriver = new LCDDisplayDriver();
    }

    public void showNumberInLCD(int number){
        lcdDisplay.showNumberLCDFormat(lcdDisplayDriver.convertNumberToLCDFormat(number));
    }
    public LCDDisplay getLcdDisplay(){
        return lcdDisplay;
    }
}
