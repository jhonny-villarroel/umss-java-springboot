package com.avantica.tutorial.designpatterns.facade;

import java.util.List;

/**
 * Created by jhonny on 8/6/2017.
 */
public class LCDDisplay {

    private List<LED> listLed;
    private String numberLCDFormat;

    public void showNumberLCDFormat(List<LED> listLCDFormat){
        listLed = listLCDFormat;
        numberLCDFormat = "";
        for (LED led: listLCDFormat){
            numberLCDFormat += led.getStatusLed() == true ? "1":"0";
        }
        System.out.println(numberLCDFormat);
    }

    public String getNumberLCDFormat(){
        return numberLCDFormat;
    }
}
