package com.avantica.tutorial.designpatterns.facade;

import sun.plugin.javascript.navig.Array;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by jhonny on 8/6/2017.
 */
public class LCDDisplayDriver {

    private Map<Integer, List<LED>> lcdMap;

    public LCDDisplayDriver(){
        lcdMap = new HashMap<Integer, List<LED>>();
        fillMapLCDFormat(lcdMap);
    }
    private void fillMapLCDFormat(Map<Integer, List<LED>> map){

        // 0 1 1 1 0 1 1 1
        map.put(0,
                Arrays.asList(
                        LED.ledOff(), LED.ledOn(), LED.ledOn(), LED.ledOn(),
                        LED.ledOff(), LED.ledOn(),LED.ledOn(), LED.ledOn()));
        // 0 0 0 0 0 1 1 0
        map.put(1,
                Arrays.asList(
                        LED.ledOff(), LED.ledOff(), LED.ledOff(), LED.ledOff(),
                        LED.ledOff(), LED.ledOn(),LED.ledOn(), LED.ledOff()));
        // 1 0 1 1 0 0 1 1
        map.put(2,
                Arrays.asList(
                        LED.ledOn(), LED.ledOff(), LED.ledOn(), LED.ledOn(),
                        LED.ledOff(), LED.ledOff(),LED.ledOn(), LED.ledOn()));
        // 1 0 0 1 0 1 1 1
        map.put(3,
                Arrays.asList(
                        LED.ledOn(), LED.ledOff(), LED.ledOff(), LED.ledOn(),
                        LED.ledOff(), LED.ledOn(),LED.ledOn(), LED.ledOn()));

        // 0 1 1 0 0 1 1 0
        map.put(4,
                Arrays.asList(
                        LED.ledOff(), LED.ledOn(), LED.ledOn(), LED.ledOff(),
                        LED.ledOff(), LED.ledOn(),LED.ledOn(), LED.ledOff()));

        // 1 1 0 1 0 1 0 1
        map.put(5,
                Arrays.asList(
                        LED.ledOn(), LED.ledOn(), LED.ledOff(), LED.ledOn(),
                        LED.ledOff(), LED.ledOn(),LED.ledOff(), LED.ledOn()));


        // TODO implement next values for now only support 0,1,2,3,4,5
    }

    public List<LED> convertNumberToLCDFormat(int number){
        return lcdMap.get(number);
    }
}
