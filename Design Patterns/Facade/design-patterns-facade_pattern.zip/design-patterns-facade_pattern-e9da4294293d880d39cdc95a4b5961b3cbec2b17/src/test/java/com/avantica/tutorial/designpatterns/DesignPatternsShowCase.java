package com.avantica.tutorial.designpatterns;

import com.avantica.tutorial.designpatterns.facade.MicrocontrollerLCD;
import org.junit.Assert;
import org.junit.Test;

import com.avantica.tutorial.designpatterns.singleton.SingletonService;

public class DesignPatternsShowCase {

    @Test
    public void singleton() {
        SingletonService instance = SingletonService.getInstance();
        SingletonService sameInstance = SingletonService.getInstance();

        Assert.assertTrue(instance == sameInstance);
    }
    @Test
    public void facade(){
        MicrocontrollerLCD microcontrollerLCD = new MicrocontrollerLCD();

        microcontrollerLCD.showNumberInLCD(5);
        Assert.assertEquals("11010101", microcontrollerLCD.getLcdDisplay().getNumberLCDFormat());
        microcontrollerLCD.showNumberInLCD(0);
        Assert.assertEquals("01110111", microcontrollerLCD.getLcdDisplay().getNumberLCDFormat());
        microcontrollerLCD.showNumberInLCD(2);
        Assert.assertEquals("10110011", microcontrollerLCD.getLcdDisplay().getNumberLCDFormat());
        microcontrollerLCD.showNumberInLCD(3);
        Assert.assertEquals("10010111", microcontrollerLCD.getLcdDisplay().getNumberLCDFormat());

    }

}
