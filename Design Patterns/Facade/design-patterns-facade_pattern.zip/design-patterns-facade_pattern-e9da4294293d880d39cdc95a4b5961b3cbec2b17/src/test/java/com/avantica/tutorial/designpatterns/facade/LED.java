package com.avantica.tutorial.designpatterns.facade;

/**
 * Created by jhonny on 8/6/2017.
 */
public class LED {

    private  boolean statusLed;

    public static LED ledOn(){
        LED newOnLed = new LED();
        newOnLed.setStatusLed(true);
        return newOnLed;
    }

    public static LED ledOff(){
        LED newOffLed = new LED();
        newOffLed.setStatusLed(false);

        return newOffLed;
    }
    public boolean getStatusLed(){
        return statusLed;
    }

    public void setStatusLed(boolean statusLed) {
        this.statusLed = statusLed;
    }

}
