package com.avantica.tutorial.designpatterns.abstract_factory;

/**
 * Created by Avantica20 on 7/4/2017.
 */
public interface DiskFactory {
    Disk createDisk(String brand, int size);
}
