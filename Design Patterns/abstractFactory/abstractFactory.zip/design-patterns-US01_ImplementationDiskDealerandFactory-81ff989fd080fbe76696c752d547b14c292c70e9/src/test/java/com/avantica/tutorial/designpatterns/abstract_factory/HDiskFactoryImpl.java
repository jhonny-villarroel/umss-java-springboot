package com.avantica.tutorial.designpatterns.abstract_factory;

/**
 * Created by Avantica20 on 7/4/2017.
 */
public class HDiskFactoryImpl implements DiskFactory {

    public Disk createDisk(String brand, int sizeMB) {
        return new HDDisk(brand, sizeMB);
    }
}
