package com.avantica.tutorial.designpatterns.abstract_factory;

import java.util.UUID;

/**
 * Created by Avantica20 on 7/4/2017.
 */
public abstract class Disk {

    protected String brand;
    protected int sizeMB;
    protected String id;

    public Disk(String brand, int sizeMB){
        this.brand = brand;
        this.sizeMB =  sizeMB;
        this.id = UUID.randomUUID().toString();
    }

    public DiskType getDiskType() {
        return diskType;
    }

    protected DiskType diskType;

    public abstract void saveInfo();

    public String  getBrand(){
        return brand;
    }

    public int getSizeMB() {
        return sizeMB;
    }

    public String getId() {
        return id;
    }

    public enum DiskType {
        SSD,
        HD
    }

}

