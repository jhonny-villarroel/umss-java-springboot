package com.avantica.tutorial.designpatterns.abstract_factory;

import java.util.UUID;

/**
 * Created by Avantica20 on 7/4/2017.
 */
public class SSDisk extends Disk {

    public SSDisk(String brand, int sizeMB) {
        super(brand, sizeMB);
    }

    @Override
    public void saveInfo() {
        System.out.print("save into Circuit integrated Memory - Flash Memory");
    }

    @Override
    public DiskType getDiskType() {
        return DiskType.SSD;
    }
}
