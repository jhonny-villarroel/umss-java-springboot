package com.avantica.tutorial.designpatterns.abstract_factory;

import com.sun.glass.ui.Size;

/**
 * Created by Avantica20 on 7/4/2017.
 */
public class DiskDealer {

    public Disk getOrder(Disk.DiskType diskType, String brand, int sizeMB){
        DiskFactory diskFactory =  null;

        switch (diskType){
            case SSD:
                diskFactory = new SSDiskFactoryImpl();
                break;
            case HD:
                diskFactory = new HDiskFactoryImpl();
        }
        return diskFactory.createDisk(brand, sizeMB);
    }
}
