package com.avantica.tutorial.designpatterns.abstract_factory;

import java.util.UUID;

/**
 * Created by Avantica20 on 7/4/2017.
 */
public class HDDisk extends Disk {

    public HDDisk(String brand, int sizeMB) {
        super(brand, sizeMB);
    }

    @Override
    public void saveInfo() {
        System.out.print("save into Magetic Storage 120GB");
    }

    @Override
    public DiskType getDiskType() {
        return DiskType.HD;
    }
}
