package com.avantica.tutorial.designpatterns;

import com.avantica.tutorial.designpatterns.abstract_factory.*;
import org.junit.Assert;
import org.junit.Test;

import com.avantica.tutorial.designpatterns.singleton.SingletonService;

public class DesignPatternsShowCase {

    @Test
    public void singleton() {
        SingletonService instance = SingletonService.getInstance();
        SingletonService sameInstance = SingletonService.getInstance();

        Assert.assertTrue(instance == sameInstance);
    }

    @Test
    public void abstractFactory(){
        DiskDealer diskDealer = new DiskDealer();
        // order one disk Type SSD
        Disk ssdDisk = diskDealer.getOrder(Disk.DiskType.SSD, "SUNDISK", 1024 );
        // review if disk is SSD
        Assert.assertTrue(ssdDisk.getDiskType() == Disk.DiskType.SSD);

        // order one disk HD
        Disk hdDisk= diskDealer.getOrder(Disk.DiskType.HD, "HITACHI", 1024);
        // review if type is HD
        Assert.assertTrue(hdDisk.getDiskType() == Disk.DiskType.HD);
        // review that id of disk are differents
        Assert.assertTrue(hdDisk.getId() != ssdDisk.getId());



    }

}
