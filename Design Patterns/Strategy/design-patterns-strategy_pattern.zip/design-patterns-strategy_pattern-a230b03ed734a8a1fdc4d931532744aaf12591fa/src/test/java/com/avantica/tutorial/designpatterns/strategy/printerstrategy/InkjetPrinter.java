package com.avantica.tutorial.designpatterns.strategy.printerstrategy;

import com.avantica.tutorial.designpatterns.strategy.printable.Image;
import com.avantica.tutorial.designpatterns.strategy.printable.PrintableObject;
import com.avantica.tutorial.designpatterns.strategy.printable.Text;

/**
 * Created by Avantica20 on 8/9/2017.
 */
public class InkjetPrinter  implements PrintStrategy{
    private static final String  PRINT_RESOLUTION  = "200DPI";
    private static final int TIME_PRINT_IMAGE = 10;
    private static final int TIME_PRINT_TEXT = 5;

    public PrintInformation printObject(PrintableObject printableObject) {
        printableObject.print();
        // fill print object information
        PrintInformation printerInfo = new PrintInformation();
        printerInfo.setPrintResolution(PRINT_RESOLUTION);
        // print any object Toner printerstrategy take only 1 Second
        if(printableObject instanceof Image){
            printerInfo.setPrintTimeDurationSeconds(TIME_PRINT_IMAGE);
        }else if(printableObject instanceof Text)
            printerInfo.setPrintTimeDurationSeconds(TIME_PRINT_TEXT);
        return printerInfo;
    }
}
