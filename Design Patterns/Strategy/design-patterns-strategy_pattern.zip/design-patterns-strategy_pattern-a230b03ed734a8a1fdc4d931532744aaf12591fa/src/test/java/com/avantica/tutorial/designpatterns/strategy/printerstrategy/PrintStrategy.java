package com.avantica.tutorial.designpatterns.strategy.printerstrategy;

import com.avantica.tutorial.designpatterns.strategy.printable.PrintableObject;

/**
 * Created by Avantica20 on 8/9/2017.
 */
public interface PrintStrategy {

    PrintInformation printObject(PrintableObject printableObject);
}
