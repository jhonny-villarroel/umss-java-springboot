package com.avantica.tutorial.designpatterns.strategy.printerstrategy;

import com.avantica.tutorial.designpatterns.strategy.printable.PrintableObject;

/**
 * Created by Avantica20 on 8/9/2017.
 */
public class TonerPrint implements PrintStrategy {
    public static final int TIME_PRINT = 1;

    public static final String  PRINT_RESOLUTION  = "120DPI";
    public PrintInformation printObject(PrintableObject printableObject) {
        printableObject.print();
        // fill print object information
        PrintInformation printerInfo = new PrintInformation();
        printerInfo.setPrintResolution(PRINT_RESOLUTION);
        // print any object Toner printerstrategy take only 5 Second
        printerInfo.setPrintTimeDurationSeconds(TIME_PRINT);
        return printerInfo;
    }
}
