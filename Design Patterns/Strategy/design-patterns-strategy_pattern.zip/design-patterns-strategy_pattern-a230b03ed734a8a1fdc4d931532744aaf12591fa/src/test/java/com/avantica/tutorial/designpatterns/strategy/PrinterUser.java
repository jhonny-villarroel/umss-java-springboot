package com.avantica.tutorial.designpatterns.strategy;

/**
 * Created by Avantica20 on 8/9/2017.
 */
public class PrinterUser {


}
