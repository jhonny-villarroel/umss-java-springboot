package com.avantica.tutorial.designpatterns.strategy.printable;

/**
 * Created by Avantica20 on 8/9/2017.
 */
public class Text implements PrintableObject {
    public void print() {
        System.out.println("Print Text!!!");
    }
}
