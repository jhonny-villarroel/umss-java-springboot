package com.avantica.tutorial.designpatterns;

import com.avantica.tutorial.designpatterns.strategy.PrinterContext;
import com.avantica.tutorial.designpatterns.strategy.printable.Image;
import com.avantica.tutorial.designpatterns.strategy.printable.Text;
import com.avantica.tutorial.designpatterns.strategy.printerstrategy.InkjetPrinter;
import com.avantica.tutorial.designpatterns.strategy.printerstrategy.PrintInformation;
import com.avantica.tutorial.designpatterns.strategy.printerstrategy.TapePrinter;
import com.avantica.tutorial.designpatterns.strategy.printerstrategy.TonerPrint;
import org.junit.Assert;
import org.junit.Test;

import com.avantica.tutorial.designpatterns.singleton.SingletonService;

public class DesignPatternsShowCase {

    @Test
    public void singleton() {
        SingletonService instance = SingletonService.getInstance();
        SingletonService sameInstance = SingletonService.getInstance();

        Assert.assertTrue(instance == sameInstance);
    }
    @Test
    public void strategy(){

        Image imagePrintable =  new Image();
        Text textPrintable =  new Text();
        // print with Toner printer
        PrinterContext printerContext =  new PrinterContext(new TonerPrint());

        PrintInformation infoPrintImageInTonerPrinter = printerContext.executePrint(imagePrintable);
        PrintInformation infoPrintTextInTonerPrinter = printerContext.executePrint(textPrintable);

        printerContext = new PrinterContext(new InkjetPrinter());
        PrintInformation infoPrintImageInInkjetPrinter = printerContext.executePrint(imagePrintable);
        PrintInformation infoPrintTextInInkjetPrinter = printerContext.executePrint(textPrintable);

        printerContext = new PrinterContext(new TapePrinter());
        PrintInformation infoPrintImageInTapePrinter = printerContext.executePrint(imagePrintable);
        PrintInformation infoPrintTextInTapePrinter = printerContext.executePrint(textPrintable);
        // compare that print any object (image or text) in Toner Print take less time
        // print Text duration compare with other strategies
        Assert.assertTrue(infoPrintTextInTonerPrinter.getPrintTimeDurationSeconds() < infoPrintTextInInkjetPrinter.getPrintTimeDurationSeconds());
        Assert.assertTrue(infoPrintTextInTonerPrinter.getPrintTimeDurationSeconds() < infoPrintTextInTapePrinter.getPrintTimeDurationSeconds());
        // print Image duration compare with other strategies
        Assert.assertTrue(infoPrintImageInTonerPrinter.getPrintTimeDurationSeconds() < infoPrintImageInInkjetPrinter.getPrintTimeDurationSeconds());
        Assert.assertTrue(infoPrintImageInTonerPrinter.getPrintTimeDurationSeconds() < infoPrintImageInTapePrinter.getPrintTimeDurationSeconds());

        // compare that print any object (image or text ) in Tape Printer take to much time
        // print Text duration compare with other strategies
        Assert.assertTrue(infoPrintTextInTapePrinter.getPrintTimeDurationSeconds() > infoPrintTextInInkjetPrinter.getPrintTimeDurationSeconds());
        Assert.assertTrue(infoPrintTextInTapePrinter.getPrintTimeDurationSeconds() > infoPrintTextInTonerPrinter.getPrintTimeDurationSeconds());
        // print Image duration compare with other strategies
        Assert.assertTrue(infoPrintImageInTapePrinter.getPrintTimeDurationSeconds() > infoPrintImageInInkjetPrinter.getPrintTimeDurationSeconds());
        Assert.assertTrue(infoPrintImageInTapePrinter.getPrintTimeDurationSeconds() > infoPrintImageInTonerPrinter.getPrintTimeDurationSeconds());





    }

}
