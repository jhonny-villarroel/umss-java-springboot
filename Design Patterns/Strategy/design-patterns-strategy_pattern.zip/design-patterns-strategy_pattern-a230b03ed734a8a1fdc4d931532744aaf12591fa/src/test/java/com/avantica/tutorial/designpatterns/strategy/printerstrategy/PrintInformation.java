package com.avantica.tutorial.designpatterns.strategy.printerstrategy;

/**
 * Created by Avantica20 on 8/9/2017.
 */
public class PrintInformation {

    private int printTimeDurationSeconds;
    private String printResolution;

    public void setPrintTimeDurationSeconds(int printTimeDurationSeconds) {
        this.printTimeDurationSeconds = printTimeDurationSeconds;
    }

    public void setPrintResolution(String printResolution) {
        this.printResolution = printResolution;
    }

    public int getPrintTimeDurationSeconds() {
        return printTimeDurationSeconds;
    }

    public String getPrintResolution() {
        return printResolution;
    }
}
