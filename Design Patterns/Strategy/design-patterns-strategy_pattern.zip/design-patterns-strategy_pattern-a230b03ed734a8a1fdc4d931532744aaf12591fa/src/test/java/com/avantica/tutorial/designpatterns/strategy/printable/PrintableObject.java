package com.avantica.tutorial.designpatterns.strategy.printable;

/**
 * Created by Avantica20 on 8/9/2017.
 */
public interface PrintableObject  {
    void print();
}
