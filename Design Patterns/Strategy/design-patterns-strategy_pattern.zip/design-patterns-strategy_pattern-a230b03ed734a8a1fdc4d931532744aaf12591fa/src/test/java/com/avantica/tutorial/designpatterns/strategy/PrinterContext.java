package com.avantica.tutorial.designpatterns.strategy;

import com.avantica.tutorial.designpatterns.strategy.printable.PrintableObject;
import com.avantica.tutorial.designpatterns.strategy.printerstrategy.PrintInformation;
import com.avantica.tutorial.designpatterns.strategy.printerstrategy.PrintStrategy;

/**
 * Created by Avantica20 on 8/9/2017.
 */
public class PrinterContext {
    private PrintStrategy printStrategy;
    public PrinterContext(PrintStrategy printStrategy){
        this.printStrategy =  printStrategy;
    }
    public PrintInformation executePrint(PrintableObject printableObject){
        return printStrategy.printObject(printableObject);
    }
}
