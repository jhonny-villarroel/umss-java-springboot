package com.avantica.tutorial.designpatterns.adapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jhonny on 8/5/2017.
 */
public class Computer {
    private List<SataDisk> listOfDisk;

    public Computer(){
        listOfDisk =  new ArrayList<SataDisk>();
    }
    public void connectDisk(SataDisk sataDisk){
        listOfDisk.add(sataDisk);
    }
    public boolean saveDataIntoDisk(SataDisk sataDisk, byte[] data){
        return sataDisk.saveDataViaSataBus(data);
    }

    public List<SataDisk> getListOfDisk() {
        return listOfDisk;
    }
}
