package com.avantica.tutorial.designpatterns.adapter;

/**
 * Created by jhonny on 8/5/2017.
 */
public interface SataDisk {

    int getDiskSizeViaSataBus();
    boolean saveDataViaSataBus(byte[] data);
}
