package com.avantica.tutorial.designpatterns.adapter;

/**
 * Created by jhonny on 8/5/2017.
 */
public class PCIEDisk implements Disk {
    private int size;
    private static final int BLOCK_SIZE = 8;
    public PCIEDisk(int size){
        this.size = size;
    }
    public int getDiskSize() {
        return size;
    }

    public boolean saveData(byte[] data) {
        System.out.print("Save data on Disk Via IDE BUS");
        if(data.length == BLOCK_SIZE)
            return true;
        else
            return false;
    }
}
