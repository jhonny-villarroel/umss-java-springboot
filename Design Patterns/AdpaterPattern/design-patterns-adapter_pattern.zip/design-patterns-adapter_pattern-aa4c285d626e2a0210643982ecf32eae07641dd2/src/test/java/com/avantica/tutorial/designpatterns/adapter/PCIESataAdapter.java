package com.avantica.tutorial.designpatterns.adapter;

/**
 * Created by jhonny on 8/5/2017.
 */
public class PCIESataAdapter implements SataDisk {
    private PCIEDisk pcieDisk;
    public PCIESataAdapter(PCIEDisk pcieDisk){
        this.pcieDisk = pcieDisk;
    }
    public int getDiskSizeViaSataBus() {
        return pcieDisk.getDiskSize();
    }

    public boolean saveDataViaSataBus(byte[] data) {
        // sata block is 2 convert to block = 8
        byte[] ataptedBlockData ={data[0], data[1], 0xa, 0xb, 0xc, 0xd, 0xe, 0xf};
        return pcieDisk.saveData(ataptedBlockData);
    }
}
