package com.avantica.tutorial.designpatterns.adapter;

/**
 * Created by jhonny on 8/5/2017.
 */
public interface Disk {
    int getDiskSize();
    boolean saveData(byte[] data);
}
