package com.avantica.tutorial.designpatterns;

import com.avantica.tutorial.designpatterns.adapter.*;
import org.junit.Assert;
import org.junit.Test;

import com.avantica.tutorial.designpatterns.singleton.SingletonService;

public class DesignPatternsShowCase {

    @Test
    public void singleton() {
        SingletonService instance = SingletonService.getInstance();
        SingletonService sameInstance = SingletonService.getInstance();

        Assert.assertTrue(instance == sameInstance);
    }

    @Test
    public  void adapter(){
        // Disk that are not SATA
        IDEDisk ideDisk =  new IDEDisk(20);
        PCIEDisk pcieDisk = new PCIEDisk(20);
        // Convert or adapt PCIE, IDE disk to SATA
        SataDisk ideToSata =  new IDESataAdapter(ideDisk);
        SataDisk pcieToSata =  new PCIESataAdapter(pcieDisk);
        // Create computer
        Computer computer = new Computer();
        // Connect Disk IDE into Computer that only accept SATA Disk
        computer.connectDisk(ideToSata);
        // Connect Disk PCIE into Computer that only accept SATA Disk
        computer.connectDisk(pcieToSata);
        // two disk connected
        Assert.assertEquals(computer.getListOfDisk().size(), 2);
        // data to save
        byte[] data = {0xa, 0xb};
        // Data save in IDE disk that only support BLOCK_SIZE = 4
        Assert.assertEquals(computer.saveDataIntoDisk(ideToSata, data),true);
        // Data save in PCEI disk that only support BLOCK_SIZE = 8
        Assert.assertEquals(computer.saveDataIntoDisk(pcieToSata, data),true);
    }


}
