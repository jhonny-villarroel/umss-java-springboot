package com.avantica.tutorial.designpatterns.adapter;

/**
 * Created by jhonny on 8/5/2017.
 */
public class IDESataAdapter implements SataDisk {
    private IDEDisk ideDisk;

    public IDESataAdapter(IDEDisk ideDisk){
        this.ideDisk =  ideDisk;
    }
    public int getDiskSizeViaSataBus() {
        return ideDisk.getDiskSize();
    }

    public boolean saveDataViaSataBus(byte[] data) {
        // Sata Data Blocke is "2" convert to IDE BLOCK "4"
        byte[] newIdeBlockData = {data[0], data[1], 0xa, 0xb};
        return ideDisk.saveData(newIdeBlockData);
    }
}
