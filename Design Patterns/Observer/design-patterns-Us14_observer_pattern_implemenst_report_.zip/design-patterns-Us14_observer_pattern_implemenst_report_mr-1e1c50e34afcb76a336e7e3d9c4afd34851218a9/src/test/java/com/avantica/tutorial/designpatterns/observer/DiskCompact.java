package com.avantica.tutorial.designpatterns.observer;

/**
 * Created by Avantica20 on 7/28/2017.
 */
public class DiskCompact {

    private String brand;
    private long size;
    private DiskType type;

    public DiskCompact(String brand, long size, DiskType type){
       this.brand = brand;
       this.size = size;
       this.type = type;
    }
    public String getBrand() {
        return brand;
    }

    public long getSize() {
        return size;
    }

    public DiskType getType() {
        return type;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public void setType(DiskType type) {
        this.type = type;
    }

    public enum DiskType{
        BLUERAY,
        DVD
    }

}

