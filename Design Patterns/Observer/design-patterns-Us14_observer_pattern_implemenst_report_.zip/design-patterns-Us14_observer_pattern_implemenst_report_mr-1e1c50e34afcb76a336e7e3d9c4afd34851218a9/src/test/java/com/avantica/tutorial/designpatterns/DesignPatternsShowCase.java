package com.avantica.tutorial.designpatterns;


import com.avantica.tutorial.designpatterns.observer.DiskCompact;
import com.avantica.tutorial.designpatterns.observer.DiskStore;
import com.avantica.tutorial.designpatterns.observer.ReportSoldDisk;
import org.junit.Assert;
import org.junit.Test;

import com.avantica.tutorial.designpatterns.singleton.SingletonService;

public class DesignPatternsShowCase {

    @Test
    public void singleton() {
        SingletonService instance = SingletonService.getInstance();
        SingletonService sameInstance = SingletonService.getInstance();

        Assert.assertTrue(instance == sameInstance);
    }

    @Test
    public void observer(){
        DiskStore diskStore =  new DiskStore();
        diskStore.addDiskToSell(new DiskCompact("PRINCO", 1024, DiskCompact.DiskType.BLUERAY));
        diskStore.addDiskToSell(new DiskCompact("TDK", 1024, DiskCompact.DiskType.DVD));
        diskStore.addDiskToSell(new DiskCompact("BLUE", 1024, DiskCompact.DiskType.DVD));

        ReportSoldDisk report =  new ReportSoldDisk();
        diskStore.addDiskSoldListener(report);

        // Sold a disk
        diskStore.sellDisk();
        int temp = report.getNumDiskSold();
        Assert.assertTrue(2 == report.getNumDiskSold());
        // one more disk
        diskStore.sellDisk();
        Assert.assertTrue(1 == report.getNumDiskSold());
    }

}
