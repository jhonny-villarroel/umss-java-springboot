package com.avantica.tutorial.designpatterns.observer;

/**
 * Created by Avantica20 on 7/28/2017.
 */
public class ReportSoldDisk implements DiskSoldListener {
    private int numDiskSold;

    public int getNumDiskSold() {
        return numDiskSold;
    }

    public void notifyDiskSold(int numOfDiskInStock) {
        System.out.println("A new DiskCompact was sold, currently we have " + numOfDiskInStock +" Disks in stock");
        numDiskSold = numOfDiskInStock;
    }
}
