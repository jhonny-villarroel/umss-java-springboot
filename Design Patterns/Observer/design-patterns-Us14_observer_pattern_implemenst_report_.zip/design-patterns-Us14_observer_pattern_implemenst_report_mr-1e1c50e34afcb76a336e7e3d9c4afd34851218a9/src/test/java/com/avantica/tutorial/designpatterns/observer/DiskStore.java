package com.avantica.tutorial.designpatterns.observer;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Avantica20 on 7/28/2017.
 */
public class DiskStore {

    private List<DiskCompact> listOfDisks;
    private List<DiskSoldListener> diskSoldListeners;
    public DiskStore(){
        listOfDisks = new ArrayList<DiskCompact>();
        diskSoldListeners = new ArrayList<DiskSoldListener>();

    }
    public void addDiskSoldListener(DiskSoldListener newListener){
        diskSoldListeners.add(newListener);
    }
    public void addDiskToSell(DiskCompact newDisk){
        listOfDisks.add(newDisk);
    }

    public DiskCompact sellDisk(){
        DiskCompact res = null;
        if(listOfDisks.size()> 0){
            res = listOfDisks.get(listOfDisks.size()-1);
            listOfDisks.remove(listOfDisks.size()-1);
            // notify that one disk was sell
            notifyDiskSold();
        }
        return  res;
    }

    private void notifyDiskSold(){
        for (DiskSoldListener diskSoldListener : diskSoldListeners) {
            diskSoldListener.notifyDiskSold(listOfDisks.size());
        }
    }

}
