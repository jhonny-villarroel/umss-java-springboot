package com.avantica.tutorial.designpatterns.observer;

/**
 * Created by Avantica20 on 7/28/2017.
 */
public interface DiskSoldListener {

    void notifyDiskSold(int numOfDiskInStock);
}
