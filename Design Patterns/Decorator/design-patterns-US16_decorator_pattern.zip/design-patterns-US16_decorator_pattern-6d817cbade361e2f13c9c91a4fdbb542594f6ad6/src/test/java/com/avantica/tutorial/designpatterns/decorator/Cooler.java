package com.avantica.tutorial.designpatterns.decorator;

/**
 * Created by jhonny on 8/1/2017.
 */
public class Cooler extends Accessory {
    private static final int PRICE = 10;
    public Cooler(IHardDisk specialHardDisk) {
        super(specialHardDisk);
    }

    @Override
    public int getPrice() {
        return this.diskWithAccesory.getPrice() + PRICE;
    }
}
