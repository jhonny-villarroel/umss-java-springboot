package com.avantica.tutorial.designpatterns.decorator;

/**
 * Created by jhonny on 8/1/2017.
 */
public interface IHardDisk {
    int getPrice();
}
