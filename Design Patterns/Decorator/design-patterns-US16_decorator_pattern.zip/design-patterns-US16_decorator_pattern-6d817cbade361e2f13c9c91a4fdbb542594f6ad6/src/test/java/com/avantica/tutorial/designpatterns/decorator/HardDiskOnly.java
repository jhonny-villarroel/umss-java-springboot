package com.avantica.tutorial.designpatterns.decorator;

/**
 * Created by jhonny on 8/1/2017.
 */
public class HardDiskOnly implements IHardDisk{
    public static int PRICE = 50;
    public HardDiskOnly(){

    }
    public int getPrice() {
        return PRICE;
    }
}
