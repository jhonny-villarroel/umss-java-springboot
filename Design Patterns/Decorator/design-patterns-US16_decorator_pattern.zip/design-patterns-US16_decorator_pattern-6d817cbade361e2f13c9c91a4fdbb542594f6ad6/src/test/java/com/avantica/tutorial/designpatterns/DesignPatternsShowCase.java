package com.avantica.tutorial.designpatterns;

import com.avantica.tutorial.designpatterns.decorator.Cooler;
import com.avantica.tutorial.designpatterns.decorator.DataCableSata;
import com.avantica.tutorial.designpatterns.decorator.HardDiskOnly;
import com.avantica.tutorial.designpatterns.decorator.IHardDisk;
import org.junit.Assert;
import org.junit.Test;

import com.avantica.tutorial.designpatterns.singleton.SingletonService;

public class DesignPatternsShowCase {

    @Test
    public void singleton() {
        SingletonService instance = SingletonService.getInstance();
        SingletonService sameInstance = SingletonService.getInstance();

        Assert.assertTrue(instance == sameInstance);
    }
    @Test
    public void decorator(){
        /* price of Cable = 20$
           price of Cooler = 10$
           price of disk only = 50$
         */
        // Hard disk with all accessories
        IHardDisk hardDiskWithAccessories = new Cooler(new DataCableSata(new HardDiskOnly()));
        Assert.assertTrue(80 == hardDiskWithAccessories.getPrice());

        // Hard disk with cooler
        IHardDisk hardDiskWithCooler = new Cooler(new HardDiskOnly());
        Assert.assertTrue(60 == hardDiskWithCooler.getPrice());

        // Hard disk with cable
        IHardDisk hardDiskWithCable = new DataCableSata(new HardDiskOnly());
        Assert.assertTrue(70 == hardDiskWithCable.getPrice());

        // Only Hard disk without any accessory
        IHardDisk hardDisk = new HardDiskOnly();
        Assert.assertTrue(50 == hardDisk.getPrice());
    }
}
