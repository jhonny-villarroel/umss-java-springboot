package com.avantica.tutorial.designpatterns.decorator;

/**
 * Created by jhonny on 8/1/2017.
 */
public class Accessory implements IHardDisk {
    protected IHardDisk diskWithAccesory;

    public Accessory(IHardDisk speciaHardDisk){
        this.diskWithAccesory = speciaHardDisk;
    }
    public int getPrice() {
        return diskWithAccesory.getPrice();
    }
}
