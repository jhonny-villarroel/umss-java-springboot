package com.avantica.tutorial.designpatterns.decorator;

/**
 * Created by jhonny on 8/1/2017.
 */
public class DataCableSata extends Cooler {
    private static final int PRICE = 20;

    public DataCableSata(IHardDisk specialHardDisk) {
        super(specialHardDisk);
    }

    @Override
    public int getPrice() {
        return this.diskWithAccesory.getPrice() + PRICE;
    }
}
