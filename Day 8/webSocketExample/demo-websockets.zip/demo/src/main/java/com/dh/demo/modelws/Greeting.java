package com.dh.demo.modelws;

/**
 * Created by jhonny on 6/17/17.
 */
public class Greeting {

    private String content;

    public Greeting() {
    }

    public Greeting(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

}
