package com.dh.demo.web;

import com.dh.demo.modelws.Greeting;
import com.dh.demo.modelws.HelloMessage;
import com.dh.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

/**
 * Created by jhonny on 6/17/17.
 */
@Controller
public class CreateMessageWSController {
    @Autowired
    UserService userService;
    @Autowired
    private SimpMessagingTemplate simpMessagingTemplate;
    // full path /app/hello
    @MessageMapping("/hello")
    // broadcast
    //@SendTo("/topic/greetings")
    public Greeting greeting(HelloMessage message) throws Exception {
        Thread.sleep(1000); // simulated delay
        simpMessagingTemplate.convertAndSend("/topic/greetings", new Greeting("Hello, " + message.getName() + "!"));
        return new Greeting("Hello, " + message.getName() + "!");
        //userService.addUser();

    }


}
